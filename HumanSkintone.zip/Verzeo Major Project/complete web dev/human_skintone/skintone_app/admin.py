from django.contrib import admin
from skintone_app.models import Image

# Register your models here.

admin.site.register(Image)